﻿namespace AoC.Day
{
    public class Day20
    {
        public static void Run(string file) {
            Console.WriteLine("Day 20: ???" + Environment.NewLine);

			string input = File.ReadAllText(file);
			string[] lines = File.ReadAllLines(file);

			Console.WriteLine();
            Console.WriteLine("Part 1: " + 0);
            //Answer: 
            Console.WriteLine("Part 2: " + 0);
            //Answer: 
        }
    }
}
